此固件为主控免驱版本，适配大明的IAP，电子脑壳和调试工具下载地址如下：

使用文档地址如下：
https://maker-community.github.io/electronbot-doc/guide/ProductionProcess/firmware.html

电子脑壳下载：https://www.microsoft.com/store/productId/9NQWDB4MQV0C

调试工具下载：https://www.microsoft.com/store/productId/9P9XF62G5R9S


