F030固件为小鹏的固件，放到这里是为方便大家使用。

访问原始仓库：
https://github.com/txp666/ElectronBot_Study
